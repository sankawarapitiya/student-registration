package lk.owl.student.reg.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@ComponentScan("lk.owl.student")
@EnableMongoRepositories(basePackages = "lk.owl.student.reg.repositories")
public class JpaConfiguration {

}
