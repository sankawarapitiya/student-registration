package lk.owl.student.reg.service;


import lk.owl.student.reg.model.Student;

import java.util.List;

public interface studentService {
	
	Student findById(String id);

	Student findByName(String name);

	void savestudent(Student Student);

	void updatestudent(Student Student);

	void deletestudentById(String id);

	void deleteAllstudents();

	List<Student> findAllstudents();

	boolean isstudentExist(Student Student);
}