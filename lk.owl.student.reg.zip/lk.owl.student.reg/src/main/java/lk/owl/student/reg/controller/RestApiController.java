package lk.owl.student.reg.controller;

import lk.owl.student.reg.model.Student;
import lk.owl.student.reg.service.studentService;
import lk.owl.student.reg.util.CustomErrorType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;

@RestController
@RequestMapping("/api")
public class RestApiController {

    public static final Logger logger = LoggerFactory.getLogger(RestApiController.class);

    @Autowired
    studentService studentService;

    // -------------------Retrieve All students---------------------------------------------

    @RequestMapping(value = "/student/", method = RequestMethod.GET)
    public ResponseEntity<List<Student>> listAllstudents() {
        List<Student> Students = studentService.findAllstudents();
        if (Students.isEmpty()) {
            return new ResponseEntity(HttpStatus.NO_CONTENT);
            // You many decide to return HttpStatus.NOT_FOUND
        }
        return new ResponseEntity<List<Student>>(Students, HttpStatus.OK);
    }

    // -------------------Retrieve Single reg------------------------------------------

    @RequestMapping(value = "/student/{id}", method = RequestMethod.GET)
    public ResponseEntity<?> getstudent(@PathVariable("id") String id) {
        logger.info("Fetching reg with id {}", id);
        Student Student = studentService.findById(id);
        if (Student == null) {
            logger.error("reg with id {} not found.", id);
            return new ResponseEntity(new CustomErrorType("reg with id " + id
                    + " not found"), HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Student>(Student, HttpStatus.OK);
    }

    // -------------------Create a reg-------------------------------------------

    @RequestMapping(value = "/student/", method = RequestMethod.POST)
    public ResponseEntity<?> createstudent(@RequestBody Student Student, UriComponentsBuilder ucBuilder) {
        logger.info("Creating reg : {}", Student);

        if (studentService.isstudentExist(Student)) {
            logger.error("Unable to create. A reg with name {} already exist", Student.getStuName());
            return new ResponseEntity(new CustomErrorType("Unable to create. A reg with name " +
                    Student.getStuName()+ " already exist."), HttpStatus.CONFLICT);
        }
        studentService.savestudent(Student);

        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ucBuilder.path("/api/reg/{id}").buildAndExpand(Student.getId()).toUri());
        return new ResponseEntity<String>(headers, HttpStatus.CREATED);
    }

    // ------------------- Update a reg ------------------------------------------------

    @RequestMapping(value = "/student/{id}", method = RequestMethod.POST)
    public ResponseEntity<?> updatestudent(@PathVariable("id") String id, @RequestBody Student Student) {
        logger.info("Updating reg with id {}", id);

        Student currentstudent = studentService.findById(id);

        if (currentstudent == null) {
            logger.error("Unable to update. reg with id {} not found.", id);
            return new ResponseEntity(new CustomErrorType("Unable to upate. reg with id " + id + " not found."),
                    HttpStatus.NOT_FOUND);
        }

        currentstudent.setStuName(Student.getStuName());
        currentstudent.setDateOfBirth(Student.getDateOfBirth());
        currentstudent.setParentName(Student.getParentName());
        currentstudent.setGrade(Student.getGrade());
        currentstudent.setAddress(Student.getAddress());
        currentstudent.setSex(Student.getSex());

        studentService.updatestudent(currentstudent);
        return new ResponseEntity<Student>(currentstudent, HttpStatus.OK);
    }

    // ------------------- Delete a reg-----------------------------------------

    @RequestMapping(value = "/student/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<?> deletestudent(@PathVariable("id") String id) {
        logger.info("Fetching & Deleting reg with id {}", id);

        Student Student = studentService.findById(id);
        if (Student == null) {
            logger.error("Unable to delete. reg with id {} not found.", id);
            return new ResponseEntity(new CustomErrorType("Unable to delete. reg with id " + id + " not found."),
                    HttpStatus.NOT_FOUND);
        }
        studentService.deletestudentById(id);
        return new ResponseEntity<Student>(HttpStatus.NO_CONTENT);
    }

    // ------------------- Delete All students-----------------------------

    @RequestMapping(value = "/student/", method = RequestMethod.DELETE)
    public ResponseEntity<Student> deleteAllstudents() {
        logger.info("Deleting All students");

        studentService.deleteAllstudents();
        return new ResponseEntity<Student>(HttpStatus.NO_CONTENT);
    }

}