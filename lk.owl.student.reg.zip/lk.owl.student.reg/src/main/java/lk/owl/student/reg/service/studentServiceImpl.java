package lk.owl.student.reg.service;

import java.util.List;

import lk.owl.student.reg.model.Student;
import lk.owl.student.reg.repositories.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



@Service("studentService")
@Transactional
public class studentServiceImpl implements studentService {

	@Autowired
	private StudentRepository studentRepository;

	public Student findById(String id) {
		return studentRepository.findOne(id);
	}

	public Student findByName(String title) {
		return studentRepository.findByStuName(title);
	}

	public void savestudent(Student student) {
		studentRepository.save(student);
	}

	public void updatestudent(Student student){
		savestudent(student);
	}

	public void deletestudentById(String id){
		studentRepository.delete(id);
	}

	public void deleteAllstudents(){
		studentRepository.deleteAll();
	}

	public List<Student> findAllstudents(){
		return studentRepository.findAll();
	}

	public boolean isstudentExist(Student student) {
		return findByName(student.getStuName()) != null;
	}
}
